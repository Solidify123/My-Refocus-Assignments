

function computeTip(totalBill){
    let mealTip = totalBill * .10;
    return mealTip;
}

console.log(computeTip(1000))